class Demo1{
	public static void main(String args[]){
	
	/*int a = 10;
	float f = a;
	
	System.out.println(f); 
	//20.8978
	float f1 = 10.0f;
	System.out.println(f1);
	
	int a1 = (int)f1;
	System.out.println(a1);
	
	//int 1variable = 10;
	//System.out.println(1variable);
	
	int $variable = 10;
	//int $variable = 10;
	System.out.println($variable); // 10
	$variable = 20;
	System.out.println($variable); // 20
	
	
	//int @variable = 10;
	//System.out.println(@variable);
	
	float FloatMarks = 10.5f;
	System.out.println(FloatMarks);
	float floatMarks1 = 10.5f;
	System.out.println(floatMarks1);*/
	
	
	//int int = 10;
	//System.out.println(int);
	
	//int String = 100;
	//System.out.println(String);
	
	//MAX_VALUE
	//MAX_PRIORITY
	//MIN_PRIORITY
	
	}


}