class DemoTest{
	
	public static void main(String args[]){
		//System.out.println("Hello world");
		//System.out.println("CDAC MUMBAI AUG 24 Batch...!!");

		/*
		ahjkashf
		aksjfha
		asjhdakjsd
		*/

		//System.out.println( "Addtion of 2 numbers " + (10 + 10) );
		
		int n1 = 10;
		int n2 = 20;
		int result ; 
		result = n1 + n2; 
		
		System.out.println( "Result " + result );
		System.out.println( "Addtion of 2 numbers " + (n1 + n2) );
		

	}

}

