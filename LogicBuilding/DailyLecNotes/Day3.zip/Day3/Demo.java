class Main{
	
	
		
	 public static void main(String args[]){
		
		String day = "true";
		
		//int a = 3, b= 1;
		switch(day){
			
			/*
			case 1.0
			case 2.0
			case 3.0
			case 1.01
			1.001
			2.01
			3.00000004
			
			
			*/
			
			
			
			
			
			/*default: 
				System.out.println("invalid input");
				break;*/
			case "True":
				System.out.println("Today is Wed");
				break;
			case "true":
				System.out.println("Today is Monday");
				break;
			/*case 3:
				System.out.println("Today is Tues");
				System.out.println("Today is Tues");
				System.out.println("Today is Tues");System.out.println("Today is Tues");System.out.println("Today is Tues");
				break;
			case 4:
				System.out.println("char 2");
				break;*/
			/*error
			case 2.0:
			System.out.println("double 2");
				break;
			*/
				//error - simple statement are not allowed.
				//System.out.println("IN switch");
						
		}
		System.out.println("after switch");
		
	
	
	
	}


}