package org.example.main;

import p1.A;
import p1.B;
import p1.C;
import p2.D;
import p2.E;

public class Program {
	public static void main(String[] args) {
		A a1 = new A();
		//a1.f1();
		
		B b1 = new B();
		//b1.f2();
		
		C c1 = new C();
		//c1.f3();
		
		D d1 = new D();
		//d1.f4();
		
		E e1 = new E();
		e1.f5();
	}
}
