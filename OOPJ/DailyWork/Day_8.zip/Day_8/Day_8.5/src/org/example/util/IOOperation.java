package org.example.util;

public enum IOOperation {
	EXIT, ACCEPT_RECORD, PRINT_RECORD
}
