package org.example.demo6;

import java.util.Arrays;

public class Program {
	public static void main(String[] args) {
		//Array of primitive / value type
		boolean[] arr = new boolean[ 3 ];
		System.out.println( Arrays.toString(arr));	//[false, false, false]
	}
}
