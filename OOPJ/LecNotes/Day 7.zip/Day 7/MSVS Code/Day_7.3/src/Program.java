package p1;
class Program {
    public static void main(String[] args) {
        Complex c = new Complex();     

        System.out.println( c );
    }    
}
