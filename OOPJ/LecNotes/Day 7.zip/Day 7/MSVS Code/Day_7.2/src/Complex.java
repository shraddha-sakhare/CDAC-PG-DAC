package p1;
public class Complex {    //p1.Complex
    public String toString( ){
        return "Complex.toString()";
    }    
}
