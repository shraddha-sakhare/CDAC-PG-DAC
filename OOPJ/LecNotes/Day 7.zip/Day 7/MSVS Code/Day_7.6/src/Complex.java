package p1.p2;
public class Complex {   
    public String toString( ){
        return "Complex.toString()";
    }    
}
