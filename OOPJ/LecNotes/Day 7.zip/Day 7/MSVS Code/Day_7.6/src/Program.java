package p1.p3;
import p1.p2.Complex;
class Program {
    public static void main(String[] args) {
        //p1.p2.Complex c = new p1.p2.Complex();     
      
        Complex c = new Complex();     
      
        System.out.println( c );

    }    
}
