package p1;
//import p1.Complex;
class Program {
    public static void main(String[] args) {
        //p1.Complex c = new p1.Complex();     
      
        Complex c = new Complex();     
      
        System.out.println( c );
    }    
}
